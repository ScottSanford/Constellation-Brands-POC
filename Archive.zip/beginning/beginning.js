angular.module('pieChartPOC')

.controller('BeginningCtrl', function($scope, $rootScope, UtilData, $location, localStorageService, ngDialog){


});