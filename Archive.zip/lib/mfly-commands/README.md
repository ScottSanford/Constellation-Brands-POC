# mflyCommands
mflyCommands.js for Mediafly Interactives

API documentation can be found at http://devdocs.mediafly.com/interactives/#
